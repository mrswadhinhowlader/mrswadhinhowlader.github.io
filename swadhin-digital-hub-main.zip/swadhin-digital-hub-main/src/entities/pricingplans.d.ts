// Re-export from main entities file for backward compatibility
export type { PricingPlans } from './index';
